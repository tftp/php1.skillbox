<?php

function errorsLoad($key) {
    $errors = [];
    $allowedType = in_array($_FILES['files']['type'][$key], ['image/png', 'image/jpeg']);
    $allowedSize = $_FILES['files']['size'][$key] / 1024 / 1024 <= 5;
    $emptyErrors = empty($_FILES['files']['error'][$key]);

    if (!$allowedType) {
        $errors[] = 'Несоответствие типов (разрешенные типы: png, jpg, jpeg)';
    }
    if (!$allowedSize) {
        $errors[] = 'Размер файла должен быть менее 5Мб';
    }
    if (!$emptyErrors) {
        $errors[] = "Ошибка загрузки {$emptyErrors}";
    }
    return $errors;
}

function withoutDir($listDir) {
    return array_diff($listDir, ['.', '..']);
}
