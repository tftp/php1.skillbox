
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <p> <a href="/form_file.php">Загрузка файлов</a> </p>
        <p> <a href="/upload.php">Просмотр загруженных файлов</a> </p>
    </body>
</html>
