
 <form  action="upload.php" method="post" enctype="multipart/form-data">
     <span>Загрузите файл 1: </span>
     <input type="file" name="myfile1" />
     <br />
     <span>Загрузите файл 2: </span>
     <input type="file" name="myfile2" />
     <br />
     <span>Загрузите файл 3: </span>
     <input type="file" name="myfile3" />
     <br />
     <span>Загрузите файл 4: </span>
     <input type="file" name="myfile4" />
     <br />
     <span>Загрузите файл 5: </span>
     <input type="file" name="myfile5" />
     <br />
     <br />
     <input type="submit" name="upload" value="Загрузить">
 </form>
