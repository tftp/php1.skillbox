<?php
include $_SERVER['DOCUMENT_ROOT'] . '/helpers.php';

$uploadPath = $_SERVER['DOCUMENT_ROOT'] . '/upload/';

?>
<pre>
<?php
if (isset($_POST['upload'])) {
    $countFiles = 0;
    foreach ($_FILES as $file) {
        if (isSuccessLoad($file)) {
            move_uploaded_file($file['tmp_name'], $uploadPath . $file['name']);
            echo "{$file['name']} загружен" . PHP_EOL;
            $countFiles += 1;
        } elseif (!empty($file['name'])) {
            echo "{$file['name']} не загружен, ошибка загрузки" . PHP_EOL;
        }
    }
    echo "{$countFiles} файлов загружено";
}

if (isset($_POST['remove']) && isset($_POST['files'])) {
    foreach ($_POST['files'] as $file) {
        // var_dump($file);
        if (unlink($uploadPath . $file)) {
            echo "{$file} удален" . PHP_EOL;
        } else {
            echo "{$file} не удален" . PHP_EOL;
        }
    }
}


$files = removeDir(scandir($uploadPath), $uploadPath);

 ?>
</pre>
<div class="">
    <table>
        <tbody>
            <form action="<?= $_SERVER['PHP_SELF']  ?>" method="post">

            <?php foreach ($files as $file): ?>
                <tr>
                    <td> <img src="/upload/<?= $file ?>" width="100px"> </td>
                    <td> <?= $file ?> </td>
                    <td> <input type="checkbox" name="files[]" value="<?= $file ?>"> </td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td><input type="submit" name="remove" value="Удалить"></td>
            </tr>

            </form>
        </tbody>
    </table>
</div>
<p> <a href="form_file.php">Форма загрузки файла</a> </p>
