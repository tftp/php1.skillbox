<?php

function checkFile($file) {
    return in_array($file['type'],['image/png', 'image/jpeg']) && ($file['size'] / 1024 / 1024 <= 2);
}

function isSuccessLoad($file) {
    return in_array($file['type'],['image/png', 'image/jpeg']) && ($file['size'] / 1024 / 1024 <= 5) && empty($file['error']);
}

function removeDir($listDir, $path) {
    $files = [];
    foreach ($listDir as  $value) {
        if (!is_dir($path . $value)) {
            $files[] = $value;
        }
    }
    return $files;
}
