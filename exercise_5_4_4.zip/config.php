<?php

$uploadPath = $_SERVER['DOCUMENT_ROOT'] . '/upload/';
$allowedType = ['image/jpg', 'image/jpeg', 'image/png'];
$allowedSize = 5;
$allowedCountFiles = 5;
