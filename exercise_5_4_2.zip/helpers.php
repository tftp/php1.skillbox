<?php

function isSuccessLoad($key) {
    $allowedType = in_array($_FILES['files']['type'][$key], ['image/png', 'image/jpeg']);
    $allowedSize = $_FILES['files']['size'][$key] / 1024 / 1024 <= 5;
    $emptyErrors = empty($_FILES['files']['error'][$key]);
    return $allowedType && $allowedSize && $emptyErrors;
}

function withoutDir($listDir) {
    $path = $_SERVER['DOCUMENT_ROOT'] . '/upload/';
    $files = [];
    foreach ($listDir as  $value) {
        if (!is_dir($path . $value)) {
            $files[] = $value;
        }
    }
    return $files;
}
