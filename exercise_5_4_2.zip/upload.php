<pre>
    <?php
    include $_SERVER['DOCUMENT_ROOT'] . '/helpers.php';
    include $_SERVER['DOCUMENT_ROOT'] . '/logic.php';
     ?>
</pre>

<div class="">
    <table>
        <tbody>
            <form action="<?= $_SERVER['PHP_SELF']  ?>" method="post">

            <?php $files = withoutDir(scandir($uploadPath)); ?>
            <?php foreach ($files as $file): ?>
                <tr>
                    <td> <img src="/upload/<?= $file ?>" width="100px"> </td>
                    <td> <?= $file ?> </td>
                    <td> <input type="checkbox" name="files[]" value="<?= $file ?>"> </td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td><input type="submit" name="remove" value="Удалить"></td>
            </tr>

            </form>
        </tbody>
    </table>
</div>
<p> <a href="/form_file.php">Форма загрузки файла</a> </p>
