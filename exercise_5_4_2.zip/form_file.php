<p>Можно выбрать не более 5 файлов.</p>
 <form  action="/upload.php" method="post" enctype="multipart/form-data">
     <span>Загрузите файл: </span>
     <input id='files' type="file"  name="files[]" required="required"  accept="image/jpeg, image/png" multiple  />
     <br />
     <br />
     <input type="submit" name="upload" value="Загрузить">
 </form>

<script type="text/javascript">
const uploadField = document.getElementById("files");
uploadField.onchange = function() {
    if(this.files.length > 5){
       alert("Слишком много файлов!");
       this.value = "";
    };
};
</script>
