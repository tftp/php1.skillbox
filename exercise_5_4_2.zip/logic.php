<?php
$uploadPath = $_SERVER['DOCUMENT_ROOT'] . '/upload/';

if (isset($_POST['upload'])) {
    $countFiles = 0;
    foreach ($_FILES['files']['name'] as $key => $file) {
        if (isSuccessLoad($key)) {
            move_uploaded_file($_FILES['files']['tmp_name'][$key], $uploadPath . $file);
            echo "{$file} загружен" . PHP_EOL;
            $countFiles += 1;
        } else {
            echo "{$file} не загружен, ошибка загрузки" . PHP_EOL;
        }
    }
    echo "{$countFiles} файлов загружено";
}

if (isset($_POST['remove']) && isset($_POST['files'])) {
    $listFiles = withoutDir(scandir($uploadPath));
    foreach ($_POST['files'] as $file) {
        if (in_array($file, $listFiles)) {
            if (unlink($uploadPath . $file)) {
                echo "{$file} удален" . PHP_EOL;
            } else {
                echo "{$file} не удален" . PHP_EOL;
            }
        }
    }
}
